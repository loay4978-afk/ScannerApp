import 'package:file_picker/file_picker.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../../data/services/pdf_service.dart';

class PdfToolsController extends GetxController {
  final isBusy = false.obs;

  Future<void> mergePdfs() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true,
    );
    if (result == null || result.paths.length < 2) return;

    isBusy.value = true;
    try {
      final paths = result.paths.whereType<String>().toList();
      final mergedPath = await PdfService.instance.mergePdfFiles(paths);
      Get.snackbar('success'.tr, 'pdf_merged'.tr);
      await Share.shareXFiles([XFile(mergedPath)]);
    } finally {
      isBusy.value = false;
    }
  }

  Future<void> splitPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (result == null || result.files.single.path == null) return;

    isBusy.value = true;
    try {
      final splitPaths = await PdfService.instance.splitPdfFile(result.files.single.path!);
      Get.snackbar('success'.tr, '${'pdf_split'.tr} (${splitPaths.length})');
      if (splitPaths.isNotEmpty) {
        await Share.shareXFiles(splitPaths.map((p) => XFile(p)).toList());
      }
    } finally {
      isBusy.value = false;
    }
  }

  Future<void> compressPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (result == null || result.files.single.path == null) return;

    isBusy.value = true;
    try {
      final compressedPath = await PdfService.instance.compressPdfFile(result.files.single.path!);
      Get.snackbar('success'.tr, 'pdf_compressed'.tr);
      await Share.shareXFiles([XFile(compressedPath)]);
    } finally {
      isBusy.value = false;
    }
  }
}
