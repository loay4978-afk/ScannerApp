import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/pdf_tools_controller.dart';

class PdfToolsView extends GetView<PdfToolsController> {
  const PdfToolsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Stack(
        children: [
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildToolCard(
                icon: Icons.merge_type_rounded,
                title: 'merge_pdf'.tr,
                subtitle: 'Combine multiple PDF documents into a single file',
                onTap: controller.mergePdfs,
              ),
              const SizedBox(height: 12),
              _buildToolCard(
                icon: Icons.call_split_rounded,
                title: 'split_pdf'.tr,
                subtitle: 'Extract every page of a PDF into separate files',
                onTap: controller.splitPdf,
              ),
              const SizedBox(height: 12),
              _buildToolCard(
                icon: Icons.compress_rounded,
                title: 'compress_pdf'.tr,
                subtitle: 'Reduce PDF file size while preserving text clarity',
                onTap: controller.compressPdf,
              ),
            ],
          ),
          if (controller.isBusy.value)
            Container(
              color: Colors.black38,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF0D9488).withOpacity(0.15),
          child: Icon(icon, color: const Color(0xFF0D9488)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
        onTap: onTap,
      ),
    );
  }
}
