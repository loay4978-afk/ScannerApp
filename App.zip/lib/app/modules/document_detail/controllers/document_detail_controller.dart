import 'dart:ui';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/database/database_helper.dart';
import '../../../data/models/document_model.dart';
import '../../../data/models/document_page_model.dart';
import '../../../data/services/ocr_service.dart';
import '../../../data/services/pdf_service.dart';
import '../../../data/services/scanner_engine_service.dart';
import '../../home/controllers/home_controller.dart';

class DocumentDetailController extends GetxController {
  late final String documentId;
  final Rx<DocumentModel?> document = Rx<DocumentModel?>(null);
  final pages = <DocumentPageModel>[].obs;
  final currentPageIndex = 0.obs;
  final isProcessing = false.obs;

  @override
  void onInit() {
    super.onInit();
    documentId = Get.arguments as String;
    loadDocument();
  }

  Future<void> loadDocument() async {
    final db = await DatabaseHelper.instance.database;
    final docMaps = await db.query('documents', where: 'id = ?', whereArgs: [documentId]);
    if (docMaps.isNotEmpty) {
      document.value = DocumentModel.fromMap(docMaps.first);
    }

    final pageMaps = await db.query(
      'document_pages',
      where: 'document_id = ?',
      whereArgs: [documentId],
      orderBy: 'page_index ASC',
    );
    pages.assignAll(pageMaps.map((e) => DocumentPageModel.fromMap(e)).toList());
  }

  Future<void> renameDocument(String newTitle) async {
    if (newTitle.trim().isEmpty || document.value == null) return;
    final db = await DatabaseHelper.instance.database;
    final updated = document.value!.copyWith(
      title: newTitle.trim(),
      updatedAt: DateTime.now().toIso8601String(),
    );
    await db.update('documents', updated.toMap(), where: 'id = ?', whereArgs: [documentId]);
    document.value = updated;
    Get.find<HomeController>().loadAllData();
  }

  Future<void> updateCategory(String newCategory) async {
    if (document.value == null) return;
    final db = await DatabaseHelper.instance.database;
    final updated = document.value!.copyWith(
      category: newCategory,
      updatedAt: DateTime.now().toIso8601String(),
    );
    await db.update('documents', updated.toMap(), where: 'id = ?', whereArgs: [documentId]);
    document.value = updated;
    Get.find<HomeController>().loadAllData();
  }

  /// Apply enhancement filter or manual crop corners to a specific page
  Future<void> updatePageProcessing({
    required DocumentPageModel page,
    String? newFilter,
    List<Offset>? newCorners,
    int? rotationDelta,
  }) async {
    isProcessing.value = true;
    try {
      final targetFilter = newFilter ?? page.filterType;
      final targetCorners = newCorners ?? page.cropPoints;
      final targetRotation = (page.rotationDegrees + (rotationDelta ?? 0)) % 360;

      final newProcessedPath = await ScannerEngineService.instance.processPage(
        originalPath: page.originalImagePath,
        normalizedCorners: targetCorners,
        filterType: targetFilter,
        rotationDegrees: targetRotation,
      );

      final updatedPage = page.copyWith(
        processedImagePath: newProcessedPath,
        filterType: targetFilter,
        cropPoints: targetCorners,
        rotationDegrees: targetRotation,
      );

      final db = await DatabaseHelper.instance.database;
      await db.update(
        'document_pages',
        updatedPage.toMap(),
        where: 'id = ?',
        whereArgs: [page.id],
      );
      await loadDocument();
    } finally {
      isProcessing.value = false;
    }
  }

  /// Reorder multi-page document
  Future<void> reorderPages(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final item = pages.removeAt(oldIndex);
    pages.insert(newIndex, item);

    final db = await DatabaseHelper.instance.database;
    for (int i = 0; i < pages.length; i++) {
      final updated = pages[i].copyWith(pageIndex: i);
      pages[i] = updated;
      await db.update(
        'document_pages',
        {'page_index': i},
        where: 'id = ?',
        whereArgs: [updated.id],
      );
    }
  }

  Future<void> deletePage(String pageId) async {
    if (pages.length <= 1) return;
    final db = await DatabaseHelper.instance.database;
    await db.delete('document_pages', where: 'id = ?', whereArgs: [pageId]);
    await loadDocument();
    if (currentPageIndex.value >= pages.length) {
      currentPageIndex.value = pages.length - 1;
    }
  }

  /// Run OCR & Invoice Extraction across all pages
  Future<void> runOcrAndInvoiceExtraction() async {
    isProcessing.value = true;
    try {
      final db = await DatabaseHelper.instance.database;
      String fullText = '';

      for (final page in pages) {
        final text = await OcrService.instance.extractTextFromImage(page.processedImagePath);
        fullText += '$text\n';
        await db.update(
          'document_pages',
          {'ocr_text': text},
          where: 'id = ?',
          whereArgs: [page.id],
        );
      }

      final invoiceData = OcrService.instance.parseInvoiceDetails(fullText);
      if (document.value != null) {
        final updatedDoc = document.value!.copyWith(
          ocrText: fullText.trim(),
          invoiceVendor: invoiceData.vendor,
          invoiceDate: invoiceData.date,
          invoiceTotal: invoiceData.total,
          updatedAt: DateTime.now().toIso8601String(),
        );
        await db.update('documents', updatedDoc.toMap(), where: 'id = ?', whereArgs: [documentId]);
        document.value = updatedDoc;
        Get.find<HomeController>().loadAllData();
      }
      await loadDocument();
    } finally {
      isProcessing.value = false;
    }
  }

  void copyOcrText() {
    final text = document.value?.ocrText ?? '';
    if (text.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: text));
      Get.snackbar('success'.tr, 'copy_text'.tr);
    }
  }

  /// Export and share PDF
  Future<void> exportAndSharePdf({int quality = 88}) async {
    if (document.value == null || pages.isEmpty) return;
    isProcessing.value = true;
    try {
      final pdfPath = await PdfService.instance.generatePdfFromPages(
        title: document.value!.title,
        pages: pages,
        imageQuality: quality,
      );

      final db = await DatabaseHelper.instance.database;
      await db.update(
        'documents',
        {'pdf_path': pdfPath},
        where: 'id = ?',
        whereArgs: [documentId],
      );

      await Share.shareXFiles([XFile(pdfPath)], text: document.value!.title);
    } finally {
      isProcessing.value = false;
    }
  }
}
