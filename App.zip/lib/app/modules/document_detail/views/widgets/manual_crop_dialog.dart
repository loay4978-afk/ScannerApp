import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../data/models/document_page_model.dart';

class ManualCropDialog extends StatefulWidget {
  final DocumentPageModel page;
  final Function(List<Offset>) onApply;

  const ManualCropDialog({
    super.key,
    required this.page,
    required this.onApply,
  });

  @override
  State<ManualCropDialog> createState() => _ManualCropDialogState();
}

class _ManualCropDialogState extends State<ManualCropDialog> {
  late List<Offset> corners;

  @override
  void initState() {
    super.initState();
    corners = List<Offset>.from(widget.page.cropPoints);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog.fullscreen(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text('crop_perspective'.tr),
          actions: [
            TextButton(
              onPressed: () {
                widget.onApply(corners);
                Get.back();
              },
              child: Text(
                'save'.tr,
                style: const TextStyle(color: Color(0xFF0D9488), fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: Center(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth - 32;
              final height = constraints.maxHeight - 80;
              return SizedBox(
                width: width,
                height: height,
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Image.file(
                        File(widget.page.originalImagePath),
                        fit: BoxFit.fill,
                      ),
                    ),
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _CropPolygonPainter(corners: corners),
                      ),
                    ),
                    for (int i = 0; i < 4; i++)
                      Positioned(
                        left: (corners[i].dx * width) - 18,
                        top: (corners[i].dy * height) - 18,
                        child: GestureDetector(
                          onPanUpdate: (details) {
                            setState(() {
                              final nx = (corners[i].dx + details.delta.dx / width).clamp(0.0, 1.0);
                              final ny = (corners[i].dy + details.delta.dy / height).clamp(0.0, 1.0);
                              corners[i] = Offset(nx, ny);
                            });
                          },
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: const Color(0xFF0D9488).withOpacity(0.85),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2.5),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _CropPolygonPainter extends CustomPainter {
  final List<Offset> corners;
  _CropPolygonPainter({required this.corners});

  @override
  void paint(Canvas canvas, Size size) {
    if (corners.length != 4) return;
    final paint = Paint()
      ..color = const Color(0xFF0D9488)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;

    final path = Path()
      ..moveTo(corners[0].dx * size.width, corners[0].dy * size.height)
      ..lineTo(corners[1].dx * size.width, corners[1].dy * size.height)
      ..lineTo(corners[2].dx * size.width, corners[2].dy * size.height)
      ..lineTo(corners[3].dx * size.width, corners[3].dy * size.height)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _CropPolygonPainter oldDelegate) => true;
}
