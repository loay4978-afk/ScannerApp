import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';
import '../controllers/document_detail_controller.dart';
import 'widgets/manual_crop_dialog.dart';

class DocumentDetailView extends GetView<DocumentDetailController> {
  const DocumentDetailView({super.key});

  @override
  Widget build(BuildContext context) {
    final filters = [
      {'id': 'original', 'label': 'filter_original'},
      {'id': 'magic', 'label': 'filter_magic'},
      {'id': 'bw', 'label': 'filter_bw'},
      {'id': 'gray', 'label': 'filter_gray'},
      {'id': 'lighten', 'label': 'filter_lighten'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Obx(
          () => InkWell(
            onTap: () => _showRenameDialog(context),
            child: Text(
              controller.document.value?.title ?? '',
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.text_snippet_outlined),
            tooltip: 'ocr_extract'.tr,
            onPressed: () => _showOcrBottomSheet(context),
          ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf_rounded, color: Color(0xFF0D9488)),
            tooltip: 'export_pdf'.tr,
            onPressed: () => controller.exportAndSharePdf(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.pages.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        final currentIdx = controller.currentPageIndex.value.clamp(0, controller.pages.length - 1);
        final currentPage = controller.pages[currentIdx];

        return Stack(
          children: [
            Column(
              children: [
                // Invoice AI Summary Banner (if detected)
                if (controller.document.value?.invoiceTotal != null &&
                    controller.document.value?.invoiceTotal != '-')
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D9488).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF0D9488)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            '${'invoice_vendor'.tr}: ${controller.document.value?.invoiceVendor ?? "-"}\n${'invoice_date'.tr}: ${controller.document.value?.invoiceDate ?? "-"}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                        Text(
                          '${'invoice_total'.tr}: ${controller.document.value?.invoiceTotal}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0D9488),
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ),

                // Main High-Resolution Processed Page Viewer
                Expanded(
                  child: PageView.builder(
                    itemCount: controller.pages.length,
                    onPageChanged: (idx) => controller.currentPageIndex.value = idx,
                    itemBuilder: (context, index) {
                      final page = controller.pages[index];
                      return InteractiveViewer(
                        minScale: 0.8,
                        maxScale: 4.0,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.file(
                              File(page.processedImagePath),
                              key: ValueKey(page.processedImagePath),
                              fit: BoxFit.contain,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // Page Counter & Quick Action Bar (Manual Crop, Rotate, Add Page, Reorder)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  color: Theme.of(context).cardColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      TextButton.icon(
                        onPressed: () {
                          Get.dialog(
                            ManualCropDialog(
                              page: currentPage,
                              onApply: (updatedCorners) {
                                controller.updatePageProcessing(
                                  page: currentPage,
                                  newCorners: updatedCorners,
                                );
                              },
                            ),
                          );
                        },
                        icon: const Icon(Icons.crop_free_rounded, size: 20),
                        label: Text('manual_crop'.tr, style: const TextStyle(fontSize: 12)),
                      ),
                      IconButton(
                        tooltip: 'rotate'.tr,
                        icon: const Icon(Icons.rotate_right_rounded),
                        onPressed: () => controller.updatePageProcessing(
                          page: currentPage,
                          rotationDelta: 90,
                        ),
                      ),
                      IconButton(
                        tooltip: 'add_page'.tr,
                        icon: const Icon(Icons.add_a_photo_outlined),
                        onPressed: () =>
                            Get.toNamed(AppRoutes.scanner, arguments: controller.documentId),
                      ),
                      IconButton(
                        tooltip: 'reorder_pages'.tr,
                        icon: const Icon(Icons.swap_vert_rounded),
                        onPressed: () => _showReorderDialog(context),
                      ),
                    ],
                  ),
                ),

                // CamScanner Enhancement Filter Strip
                Container(
                  height: 64,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  color: Theme.of(context).cardColor,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    itemCount: filters.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, idx) {
                      final f = filters[idx];
                      final isSelected = currentPage.filterType == f['id'];
                      return ChoiceChip(
                        label: Text(f['label']!.tr),
                        selected: isSelected,
                        onSelected: (_) => controller.updatePageProcessing(
                          page: currentPage,
                          newFilter: f['id'],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            if (controller.isProcessing.value)
              Container(
                color: Colors.black45,
                child: const Center(child: CircularProgressIndicator()),
              ),
          ],
        );
      }),
    );
  }

  void _showRenameDialog(BuildContext context) {
    final ctrl = TextEditingController(text: controller.document.value?.title ?? '');
    Get.defaultDialog(
      title: 'documents'.tr,
      content: TextField(controller: ctrl),
      textConfirm: 'save'.tr,
      textCancel: 'cancel'.tr,
      onConfirm: () {
        controller.renameDocument(ctrl.text);
        Get.back();
      },
    );
  }

  void _showOcrBottomSheet(BuildContext context) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('extracted_text'.tr,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: controller.runOcrAndInvoiceExtraction,
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy),
                      onPressed: controller.copyOcrText,
                    ),
                  ],
                ),
              ],
            ),
            const Divider(),
            SizedBox(
              height: 220,
              child: SingleChildScrollView(
                child: Obx(
                  () => SelectableText(
                    controller.document.value?.ocrText.isNotEmpty == true
                        ? controller.document.value!.ocrText
                        : 'No text detected yet.',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showReorderDialog(BuildContext context) {
    Get.dialog(
      AlertDialog(
        title: Text('reorder_pages'.tr),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: Obx(
            () => ReorderableListView.builder(
              itemCount: controller.pages.length,
              onReorder: controller.reorderPages,
              itemBuilder: (context, index) {
                final page = controller.pages[index];
                return ListTile(
                  key: ValueKey(page.id),
                  leading: Image.file(File(page.processedImagePath), width: 40, height: 50),
                  title: Text('${'pages'.tr} ${index + 1}'),
                  trailing: const Icon(Icons.drag_handle),
                );
              },
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('save'.tr)),
        ],
      ),
    );
  }
}
