import 'dart:io';
import 'package:camera/camera.dart';
import 'package:get/get.dart';
import '../../home/controllers/home_controller.dart';

class ScannerController extends GetxController {
  CameraController? cameraController;
  final isCameraInitialized = false.obs;
  final isFlashOn = false.obs;
  final isBatchMode = true.obs;
  final capturedFiles = <File>[].obs;
  final isCapturing = false.obs;

  String? attachToDocumentId;

  @override
  void onInit() {
    super.onInit();
    if (Get.arguments is String) {
      attachToDocumentId = Get.arguments as String;
    }
    initCamera();
  }

  Future<void> initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) return;

      final backCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      cameraController = CameraController(
        backCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await cameraController!.initialize();
      isCameraInitialized.value = true;
    } catch (_) {
      isCameraInitialized.value = false;
    }
  }

  Future<void> toggleFlash() async {
    if (cameraController == null || !isCameraInitialized.value) return;
    isFlashOn.value = !isFlashOn.value;
    await cameraController!.setFlashMode(
      isFlashOn.value ? FlashMode.torch : FlashMode.off,
    );
  }

  Future<void> capturePhoto() async {
    if (cameraController == null || !isCameraInitialized.value || isCapturing.value) return;
    isCapturing.value = true;
    try {
      final XFile photo = await cameraController!.takePicture();
      final file = File(photo.path);
      capturedFiles.add(file);

      if (!isBatchMode.value) {
        await finishScanning();
      }
    } finally {
      isCapturing.value = false;
    }
  }

  Future<void> finishScanning() async {
    if (capturedFiles.isEmpty) return;
    final filesToProcess = List<File>.from(capturedFiles);
    capturedFiles.clear();
    Get.back();
    await Get.find<HomeController>().createDocumentFromImageFiles(
      filesToProcess,
      attachToDocumentId: attachToDocumentId,
    );
  }

  @override
  void onClose() {
    cameraController?.dispose();
    super.onClose();
  }
}
