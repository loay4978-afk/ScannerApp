import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/scanner_controller.dart';

class ScannerView extends GetView<ScannerController> {
  const ScannerView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('scan_camera'.tr),
        actions: [
          Obx(
            () => IconButton(
              icon: Icon(controller.isFlashOn.value ? Icons.flash_on : Icons.flash_off),
              onPressed: controller.toggleFlash,
            ),
          ),
        ],
      ),
      body: Obx(() {
        if (!controller.isCameraInitialized.value || controller.cameraController == null) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFF0D9488)),
          );
        }

        return Stack(
          fit: StackFit.expand,
          children: [
            CameraPreview(controller.cameraController!),

            IgnorePointer(
              child: Container(
                margin: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFF0D9488), width: 2.5),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            Positioned(
              left: 0,
              right: 0,
              bottom: 28,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Obx(
                    () => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white38),
                      ),
                      child: Text(
                        '${controller.capturedFiles.length} ${'pages'.tr}',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),

                  GestureDetector(
                    onTap: controller.capturePhoto,
                    child: Container(
                      width: 74,
                      height: 74,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                        color: const Color(0xFF0D9488),
                      ),
                      child: const Icon(Icons.camera_alt, color: Colors.white, size: 32),
                    ),
                  ),

                  Obx(
                    () => ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: controller.capturedFiles.isNotEmpty
                            ? const Color(0xFF0D9488)
                            : Colors.grey.shade800,
                        foregroundColor: Colors.white,
                      ),
                      onPressed:
                          controller.capturedFiles.isNotEmpty ? controller.finishScanning : null,
                      icon: const Icon(Icons.check),
                      label: Text('save'.tr),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      }),
    );
  }
}
