import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../../../core/database/database_helper.dart';
import '../../../data/models/account_model.dart';
import '../../../data/models/document_model.dart';
import '../../../data/models/document_page_model.dart';
import '../../../data/models/folder_model.dart';
import '../../../data/models/transaction_model.dart';
import '../../../data/models/user_model.dart';
import '../../../data/services/ocr_service.dart';
import '../../../data/services/scanner_engine_service.dart';
import '../../../routes/app_routes.dart';

class HomeController extends GetxController {
  final currentTabIndex = 0.obs;
  final isLoading = false.obs;

  final documents = <DocumentModel>[].obs;
  final filteredDocuments = <DocumentModel>[].obs;
  final folders = <FolderModel>[].obs;
  final transactions = <TransactionModel>[].obs;

  final Rx<UserModel?> currentUser = Rx<UserModel?>(null);
  final Rx<AccountModel?> currentAccount = Rx<AccountModel?>(null);

  final selectedCategory = 'all_docs'.obs;
  final selectedFolderId = RxnString();
  final searchQuery = ''.obs;

  final ImagePicker _picker = ImagePicker();

  @override
  void onInit() {
    super.onInit();
    loadAllData();
    everAll([documents, selectedCategory, selectedFolderId, searchQuery], (_) => _applyFilters());
  }

  Future<void> loadAllData() async {
    isLoading.value = true;
    final db = await DatabaseHelper.instance.database;

    final userMaps = await db.query('users', limit: 1);
    if (userMaps.isNotEmpty) {
      currentUser.value = UserModel.fromMap(userMaps.first);
    }

    final accMaps = await db.query('accounts', limit: 1);
    if (accMaps.isNotEmpty) {
      currentAccount.value = AccountModel.fromMap(accMaps.first);
    }

    final txMaps = await db.query('transactions', orderBy: 'created_at DESC');
    transactions.assignAll(txMaps.map((e) => TransactionModel.fromMap(e)).toList());

    final folderMaps = await db.query('folders', orderBy: 'created_at DESC');
    folders.assignAll(folderMaps.map((e) => FolderModel.fromMap(e)).toList());

    final docMaps = await db.query('documents', orderBy: 'updated_at DESC');
    documents.assignAll(docMaps.map((e) => DocumentModel.fromMap(e)).toList());

    isLoading.value = false;
  }

  void _applyFilters() {
    final q = searchQuery.value.toLowerCase().trim();
    final cat = selectedCategory.value;
    final folderId = selectedFolderId.value;

    final result = documents.where((doc) {
      final matchesCat = cat == 'all_docs' || doc.category == cat;
      final matchesFolder = folderId == null || doc.folderId == folderId;
      final matchesQuery = q.isEmpty ||
          doc.title.toLowerCase().contains(q) ||
          doc.ocrText.toLowerCase().contains(q) ||
          (doc.invoiceVendor?.toLowerCase().contains(q) ?? false);
      return matchesCat && matchesFolder && matchesQuery;
    }).toList();

    filteredDocuments.assignAll(result);
  }

  /// Batch import multiple images from Gallery and auto-detect edges for each page
  Future<void> importImagesFromGallery({String? attachToDocumentId}) async {
    final List<XFile> picked = await _picker.pickMultiImage(imageQuality: 95);
    if (picked.isEmpty) return;

    await createDocumentFromImageFiles(
      picked.map((x) => File(x.path)).toList(),
      attachToDocumentId: attachToDocumentId,
    );
  }

  /// Core batch scan creation pipeline
  Future<void> createDocumentFromImageFiles(
    List<File> files, {
    String? attachToDocumentId,
  }) async {
    if (files.isEmpty) return;
    isLoading.value = true;

    try {
      final db = await DatabaseHelper.instance.database;
      final appDir = await getApplicationDocumentsDirectory();
      final rawDir = Directory(p.join(appDir.path, 'raw_scans'));
      if (!await rawDir.exists()) await rawDir.create(recursive: true);

      final now = DateTime.now().toIso8601String();
      final docId = attachToDocumentId ?? const Uuid().v4();

      int startIndex = 0;
      if (attachToDocumentId != null) {
        final existingPages = await db.query(
          'document_pages',
          where: 'document_id = ?',
          whereArgs: [attachToDocumentId],
        );
        startIndex = existingPages.length;
      }

      String combinedOcr = '';
      for (int i = 0; i < files.length; i++) {
        final savedOriginalPath = p.join(rawDir.path, 'raw_${const Uuid().v4()}.jpg');
        await files[i].copy(savedOriginalPath);

        // 1. Auto-detect edges
        final corners = await ScannerEngineService.instance.detectDocumentEdges(savedOriginalPath);

        // 2. Apply perspective warp + Magic Color enhancement
        final processedPath = await ScannerEngineService.instance.processPage(
          originalPath: savedOriginalPath,
          normalizedCorners: corners,
          filterType: 'magic',
          rotationDegrees: 0,
        );

        // 3. Offline OCR extraction
        final pageText = await OcrService.instance.extractTextFromImage(processedPath);
        if (pageText.isNotEmpty) {
          combinedOcr += '$pageText\n';
        }

        final pageModel = DocumentPageModel(
          id: const Uuid().v4(),
          documentId: docId,
          pageIndex: startIndex + i,
          originalImagePath: savedOriginalPath,
          processedImagePath: processedPath,
          filterType: 'magic',
          rotationDegrees: 0,
          cropPoints: corners,
          ocrText: pageText,
          createdAt: now,
        );

        await db.insert('document_pages', pageModel.toMap());
      }

      if (attachToDocumentId == null) {
        final parsedInvoice = OcrService.instance.parseInvoiceDetails(combinedOcr);
        final isLikelyInvoice = parsedInvoice.total != '-';

        final newDoc = DocumentModel(
          id: docId,
          folderId: selectedFolderId.value,
          title: 'Scan_${DateTime.now().year}${DateTime.now().month.toString().padLeft(2, '0')}${DateTime.now().day.toString().padLeft(2, '0')}_${DateTime.now().hour}${DateTime.now().minute}',
          category: isLikelyInvoice ? 'invoices' : 'all_docs',
          ocrText: combinedOcr.trim(),
          invoiceVendor: isLikelyInvoice ? parsedInvoice.vendor : null,
          invoiceDate: isLikelyInvoice ? parsedInvoice.date : null,
          invoiceTotal: isLikelyInvoice ? parsedInvoice.total : null,
          isSynced: currentUser.value?.cloudEnabled ?? false,
          createdAt: now,
          updatedAt: now,
        );
        await db.insert('documents', newDoc.toMap());
      } else {
        await db.update(
          'documents',
          {'updated_at': now},
          where: 'id = ?',
          whereArgs: [docId],
        );
      }

      await loadAllData();
      Get.toNamed(AppRoutes.documentDetail, arguments: docId);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createFolder(String name) async {
    if (name.trim().isEmpty) return;
    final db = await DatabaseHelper.instance.database;
    final folder = FolderModel(
      id: const Uuid().v4(),
      name: name.trim(),
      colorHex: '#0D9488',
      iconName: 'folder',
      createdAt: DateTime.now().toIso8601String(),
    );
    await db.insert('folders', folder.toMap());
    await loadAllData();
  }

  Future<void> deleteDocument(String docId) async {
    final db = await DatabaseHelper.instance.database;
    await db.delete('document_pages', where: 'document_id = ?', whereArgs: [docId]);
    await db.delete('documents', where: 'id = ?', whereArgs: [docId]);
    await loadAllData();
  }

  Future<void> upgradeToPro() async {
    final db = await DatabaseHelper.instance.database;
    final now = DateTime.now().toIso8601String();

    await db.update(
      'users',
      {'is_pro': 1, 'cloud_enabled': 1},
      where: 'id = ?',
      whereArgs: ['user_default'],
    );

    await db.update(
      'accounts',
      {
        'plan_name': 'CamScan Pro Unlimited',
        'storage_limit_mb': 102400.0,
        'credits': 9999,
      },
      where: 'id = ?',
      whereArgs: ['acc_default'],
    );

    await db.insert('transactions', {
      'id': const Uuid().v4(),
      'user_id': 'user_default',
      'title': 'CamScan Pro Lifetime / Annual License',
      'amount': 19.99,
      'currency': 'USD',
      'status': 'Completed',
      'created_at': now,
    });

    await loadAllData();
    Get.snackbar('success'.tr, 'pro_plan'.tr);
  }

  void changeLanguage(String langCode, String countryCode) {
    Get.updateLocale(Locale(langCode, countryCode));
  }
}
