import 'package:get/get.dart';
import '../../pdf_tools/controllers/pdf_tools_controller.dart';
import '../controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(() => HomeController());
    Get.lazyPut<PdfToolsController>(() => PdfToolsController());
  }
}
