import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../data/models/document_model.dart';

class DocumentCardWidget extends StatelessWidget {
  final DocumentModel document;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const DocumentCardWidget({
    super.key,
    required this.document,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        leading: Container(
          width: 48,
          height: 56,
          decoration: BoxDecoration(
            color: const Color(0xFF0D9488).withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            document.category == 'invoices'
                ? Icons.receipt_long_rounded
                : Icons.description_rounded,
            color: const Color(0xFF0D9488),
            size: 28,
          ),
        ),
        title: Text(
          document.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              '${document.category.tr} • ${document.updatedAt.split("T").first}',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
            if (document.invoiceTotal != null && document.invoiceTotal != '-')
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  '${'invoice_total'.tr}: ${document.invoiceTotal} (${document.invoiceVendor ?? ""})',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF0D9488),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
          onPressed: onDelete,
        ),
      ),
    );
  }
}
