import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';
import '../../pdf_tools/views/pdf_tools_view.dart';
import '../controllers/home_controller.dart';
import 'widgets/document_card_widget.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = ['all_docs', 'invoices', 'contracts', 'ids', 'notes'];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.document_scanner_rounded, color: Color(0xFF0D9488)),
            const SizedBox(width: 8),
            Text('app_name'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(width: 8),
            Obx(() {
              final isPro = controller.currentUser.value?.isPro ?? false;
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: isPro ? const Color(0xFFF59E0B) : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  isPro ? 'PRO' : 'FREE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: isPro ? Colors.white : Colors.black87,
                  ),
                ),
              );
            }),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.photo_library_outlined),
            tooltip: 'import_gallery'.tr,
            onPressed: () => controller.importImagesFromGallery(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.currentTabIndex.value == 1) {
          return _buildFoldersTab(context);
        } else if (controller.currentTabIndex.value == 2) {
          return const PdfToolsView();
        } else if (controller.currentTabIndex.value == 3) {
          return _buildSettingsTab(context);
        }

        return Column(
          children: [
            // Search Bar (searches Document Title, OCR text & Invoice Vendor)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                onChanged: (val) => controller.searchQuery.value = val,
                decoration: InputDecoration(
                  hintText: 'search_hint'.tr,
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Theme.of(context).cardColor,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),

            // Category Filter Chips
            SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final cat = categories[index];
                  return Obx(() {
                    final selected = controller.selectedCategory.value == cat;
                    return ChoiceChip(
                      label: Text(cat.tr),
                      selected: selected,
                      onSelected: (_) => controller.selectedCategory.value = cat,
                    );
                  });
                },
              ),
            ),

            const SizedBox(height: 8),

            // Documents List
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (controller.filteredDocuments.isEmpty) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.document_scanner_outlined,
                              size: 72, color: Colors.grey.shade400),
                          const SizedBox(height: 16),
                          Text(
                            'no_documents'.tr,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                  itemCount: controller.filteredDocuments.length,
                  itemBuilder: (context, index) {
                    final doc = controller.filteredDocuments[index];
                    return DocumentCardWidget(
                      document: doc,
                      onTap: () => Get.toNamed(AppRoutes.documentDetail, arguments: doc.id),
                      onDelete: () => controller.deleteDocument(doc.id),
                    );
                  },
                );
              }),
            ),
          ],
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed(AppRoutes.scanner),
        icon: const Icon(Icons.camera_alt_rounded),
        label: Text('scan_camera'.tr),
      ),
      bottomNavigationBar: Obx(
        () => NavigationBar(
          selectedIndex: controller.currentTabIndex.value,
          onDestinationSelected: (idx) {
            controller.selectedFolderId.value = null;
            controller.currentTabIndex.value = idx;
          },
          destinations: [
            NavigationDestination(
              icon: const Icon(Icons.description_outlined),
              selectedIcon: const Icon(Icons.description),
              label: 'documents'.tr,
            ),
            NavigationDestination(
              icon: const Icon(Icons.folder_outlined),
              selectedIcon: const Icon(Icons.folder),
              label: 'folders'.tr,
            ),
            NavigationDestination(
              icon: const Icon(Icons.picture_as_pdf_outlined),
              selectedIcon: const Icon(Icons.picture_as_pdf),
              label: 'tools'.tr,
            ),
            NavigationDestination(
              icon: const Icon(Icons.settings_outlined),
              selectedIcon: const Icon(Icons.settings),
              label: 'settings'.tr,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFoldersTab(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.3,
          ),
          itemCount: controller.folders.length + 1,
          itemBuilder: (context, index) {
            if (index == 0) {
              return InkWell(
                onTap: () => _showCreateFolderDialog(context),
                borderRadius: BorderRadius.circular(14),
                child: Card(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.create_new_folder_outlined,
                          size: 36, color: Color(0xFF0D9488)),
                      const SizedBox(height: 8),
                      Text('new_folder'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            }
            final folder = controller.folders[index - 1];
            return InkWell(
              onTap: () {
                controller.selectedFolderId.value = folder.id;
                controller.currentTabIndex.value = 0;
              },
              borderRadius: BorderRadius.circular(14),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Icon(Icons.folder_rounded, size: 36, color: Color(0xFF0D9488)),
                      Text(
                        folder.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showCreateFolderDialog(BuildContext context) {
    final textCtrl = TextEditingController();
    Get.defaultDialog(
      title: 'new_folder'.tr,
      content: TextField(
        controller: textCtrl,
        decoration: InputDecoration(hintText: 'folder_name'.tr),
      ),
      textConfirm: 'create'.tr,
      textCancel: 'cancel'.tr,
      onConfirm: () {
        controller.createFolder(textCtrl.text);
        Get.back();
      },
    );
  }

  Widget _buildSettingsTab(BuildContext context) {
    return Obx(() {
      final user = controller.currentUser.value;
      final account = controller.currentAccount.value;
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        user?.isPro == true ? 'pro_plan'.tr : 'free_plan'.tr,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const Icon(Icons.verified_rounded, color: Color(0xFFF59E0B)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('Plan: ${account?.planName ?? "Free"}'),
                  Text('Credits: ${account?.credits ?? 0}'),
                  const SizedBox(height: 12),
                  if (user?.isPro != true)
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF59E0B),
                          foregroundColor: Colors.white,
                        ),
                        onPressed: () => controller.upgradeToPro(),
                        icon: const Icon(Icons.workspace_premium),
                        label: Text('upgrade_pro'.tr),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.language),
                  title: Text('language'.tr),
                  trailing: DropdownButton<String>(
                    value: Get.locale?.languageCode ?? 'ar',
                    underline: const SizedBox(),
                    items: const [
                      DropdownMenuItem(value: 'ar', child: Text('العربية')),
                      DropdownMenuItem(value: 'en', child: Text('English')),
                      DropdownMenuItem(value: 'de', child: Text('Deutsch')),
                    ],
                    onChanged: (val) {
                      if (val == 'ar') controller.changeLanguage('ar', 'SA');
                      if (val == 'en') controller.changeLanguage('en', 'US');
                      if (val == 'de') controller.changeLanguage('de', 'DE');
                    },
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.offline_pin_rounded, color: Colors.green),
                  title: Text('offline_ready'.tr),
                  subtitle: const Text('SQLite + On-Device ML Kit OCR + Edge Engine'),
                ),
              ],
            ),
          ),
          if (controller.transactions.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('transactions'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...controller.transactions.map(
              (tx) => Card(
                child: ListTile(
                  leading: const Icon(Icons.receipt_outlined),
                  title: Text(tx.title),
                  subtitle: Text(tx.createdAt.split('T').first),
                  trailing: Text('\$${tx.amount} ${tx.currency}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ],
      );
    });
  }
}
