import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('camscan_pro.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        is_pro INTEGER NOT NULL DEFAULT 0,
        cloud_enabled INTEGER NOT NULL DEFAULT 0,
        language_code TEXT NOT NULL DEFAULT 'ar',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE accounts (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        plan_name TEXT NOT NULL,
        storage_used_mb REAL NOT NULL DEFAULT 0,
        storage_limit_mb REAL NOT NULL DEFAULT 500,
        credits INTEGER NOT NULL DEFAULT 10,
        expires_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        currency TEXT NOT NULL DEFAULT 'USD',
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE folders (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        color_hex TEXT NOT NULL,
        icon_name TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE documents (
        id TEXT PRIMARY KEY,
        folder_id TEXT,
        title TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'all_docs',
        ocr_text TEXT NOT NULL DEFAULT '',
        invoice_vendor TEXT,
        invoice_date TEXT,
        invoice_total TEXT,
        pdf_path TEXT,
        is_synced INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE document_pages (
        id TEXT PRIMARY KEY,
        document_id TEXT NOT NULL,
        page_index INTEGER NOT NULL,
        original_image_path TEXT NOT NULL,
        processed_image_path TEXT NOT NULL,
        filter_type TEXT NOT NULL DEFAULT 'magic',
        rotation_degrees INTEGER NOT NULL DEFAULT 0,
        crop_points_json TEXT NOT NULL,
        ocr_text TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');

    final now = DateTime.now().toIso8601String();
    await db.insert('users', {
      'id': 'user_default',
      'name': 'CamScan User',
      'email': 'user@camscan.pro',
      'is_pro': 0,
      'cloud_enabled': 0,
      'language_code': 'ar',
      'created_at': now,
    });

    await db.insert('accounts', {
      'id': 'acc_default',
      'user_id': 'user_default',
      'plan_name': 'Free Plan',
      'storage_used_mb': 0.0,
      'storage_limit_mb': 1024.0,
      'credits': 25,
      'expires_at': null,
    });

    await db.insert('folders', {
      'id': 'folder_invoices',
      'name': 'Invoices / الفواتير',
      'color_hex': '#0D9488',
      'icon_name': 'receipt_long',
      'created_at': now,
    });

    await db.insert('folders', {
      'id': 'folder_contracts',
      'name': 'Contracts / العقود',
      'color_hex': '#2563EB',
      'icon_name': 'description',
      'created_at': now,
    });
  }
}
