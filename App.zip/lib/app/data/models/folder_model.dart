class FolderModel {
  final String id;
  final String name;
  final String colorHex;
  final String iconName;
  final String createdAt;

  FolderModel({
    required this.id,
    required this.name,
    required this.colorHex,
    required this.iconName,
    required this.createdAt,
  });

  factory FolderModel.fromMap(Map<String, dynamic> map) {
    return FolderModel(
      id: map['id'],
      name: map['name'],
      colorHex: map['color_hex'],
      iconName: map['icon_name'],
      createdAt: map['created_at'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'color_hex': colorHex,
      'icon_name': iconName,
      'created_at': createdAt,
    };
  }
}
