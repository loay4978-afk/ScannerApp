class DocumentModel {
  final String id;
  final String? folderId;
  final String title;
  final String category;
  final String ocrText;
  final String? invoiceVendor;
  final String? invoiceDate;
  final String? invoiceTotal;
  final String? pdfPath;
  final bool isSynced;
  final String createdAt;
  final String updatedAt;

  DocumentModel({
    required this.id,
    this.folderId,
    required this.title,
    this.category = 'all_docs',
    this.ocrText = '',
    this.invoiceVendor,
    this.invoiceDate,
    this.invoiceTotal,
    this.pdfPath,
    this.isSynced = false,
    required this.createdAt,
    required this.updatedAt,
  });

  factory DocumentModel.fromMap(Map<String, dynamic> map) {
    return DocumentModel(
      id: map['id'],
      folderId: map['folder_id'],
      title: map['title'],
      category: map['category'] ?? 'all_docs',
      ocrText: map['ocr_text'] ?? '',
      invoiceVendor: map['invoice_vendor'],
      invoiceDate: map['invoice_date'],
      invoiceTotal: map['invoice_total'],
      pdfPath: map['pdf_path'],
      isSynced: (map['is_synced'] ?? 0) == 1,
      createdAt: map['created_at'],
      updatedAt: map['updated_at'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'folder_id': folderId,
      'title': title,
      'category': category,
      'ocr_text': ocrText,
      'invoice_vendor': invoiceVendor,
      'invoice_date': invoiceDate,
      'invoice_total': invoiceTotal,
      'pdf_path': pdfPath,
      'is_synced': isSynced ? 1 : 0,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }

  DocumentModel copyWith({
    String? folderId,
    String? title,
    String? category,
    String? ocrText,
    String? invoiceVendor,
    String? invoiceDate,
    String? invoiceTotal,
    String? pdfPath,
    bool? isSynced,
    String? updatedAt,
  }) {
    return DocumentModel(
      id: id,
      folderId: folderId ?? this.folderId,
      title: title ?? this.title,
      category: category ?? this.category,
      ocrText: ocrText ?? this.ocrText,
      invoiceVendor: invoiceVendor ?? this.invoiceVendor,
      invoiceDate: invoiceDate ?? this.invoiceDate,
      invoiceTotal: invoiceTotal ?? this.invoiceTotal,
      pdfPath: pdfPath ?? this.pdfPath,
      isSynced: isSynced ?? this.isSynced,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
