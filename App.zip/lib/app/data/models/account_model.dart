class AccountModel {
  final String id;
  final String userId;
  final String planName;
  final double storageUsedMb;
  final double storageLimitMb;
  final int credits;
  final String? expiresAt;

  AccountModel({
    required this.id,
    required this.userId,
    required this.planName,
    required this.storageUsedMb,
    required this.storageLimitMb,
    required this.credits,
    this.expiresAt,
  });

  factory AccountModel.fromMap(Map<String, dynamic> map) {
    return AccountModel(
      id: map['id'],
      userId: map['user_id'],
      planName: map['plan_name'],
      storageUsedMb: (map['storage_used_mb'] ?? 0).toDouble(),
      storageLimitMb: (map['storage_limit_mb'] ?? 1024).toDouble(),
      credits: map['credits'] ?? 0,
      expiresAt: map['expires_at'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'plan_name': planName,
      'storage_used_mb': storageUsedMb,
      'storage_limit_mb': storageLimitMb,
      'credits': credits,
      'expires_at': expiresAt,
    };
  }
}
