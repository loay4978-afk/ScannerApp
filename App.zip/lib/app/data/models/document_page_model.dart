import 'dart:convert';
import 'dart:ui';

class DocumentPageModel {
  final String id;
  final String documentId;
  final int pageIndex;
  final String originalImagePath;
  final String processedImagePath;
  final String filterType;
  final int rotationDegrees;
  final List<Offset> cropPoints;
  final String ocrText;
  final String createdAt;

  DocumentPageModel({
    required this.id,
    required this.documentId,
    required this.pageIndex,
    required this.originalImagePath,
    required this.processedImagePath,
    this.filterType = 'magic',
    this.rotationDegrees = 0,
    required this.cropPoints,
    this.ocrText = '',
    required this.createdAt,
  });

  factory DocumentPageModel.fromMap(Map<String, dynamic> map) {
    final List<dynamic> rawPoints = jsonDecode(map['crop_points_json'] ?? '[]');
    final points = rawPoints
        .map((p) => Offset((p['dx'] as num).toDouble(), (p['dy'] as num).toDouble()))
        .toList();
    return DocumentPageModel(
      id: map['id'],
      documentId: map['document_id'],
      pageIndex: map['page_index'] ?? 0,
      originalImagePath: map['original_image_path'],
      processedImagePath: map['processed_image_path'],
      filterType: map['filter_type'] ?? 'magic',
      rotationDegrees: map['rotation_degrees'] ?? 0,
      cropPoints: points.length == 4
          ? points
          : const [
              Offset(0.05, 0.05),
              Offset(0.95, 0.05),
              Offset(0.95, 0.95),
              Offset(0.05, 0.95),
            ],
      ocrText: map['ocr_text'] ?? '',
      createdAt: map['created_at'],
    );
  }

  Map<String, dynamic> toMap() {
    final pointsJson = jsonEncode(
      cropPoints.map((p) => {'dx': p.dx, 'dy': p.dy}).toList(),
    );
    return {
      'id': id,
      'document_id': documentId,
      'page_index': pageIndex,
      'original_image_path': originalImagePath,
      'processed_image_path': processedImagePath,
      'filter_type': filterType,
      'rotation_degrees': rotationDegrees,
      'crop_points_json': pointsJson,
      'ocr_text': ocrText,
      'created_at': createdAt,
    };
  }

  DocumentPageModel copyWith({
    int? pageIndex,
    String? processedImagePath,
    String? filterType,
    int? rotationDegrees,
    List<Offset>? cropPoints,
    String? ocrText,
  }) {
    return DocumentPageModel(
      id: id,
      documentId: documentId,
      pageIndex: pageIndex ?? this.pageIndex,
      originalImagePath: originalImagePath,
      processedImagePath: processedImagePath ?? this.processedImagePath,
      filterType: filterType ?? this.filterType,
      rotationDegrees: rotationDegrees ?? this.rotationDegrees,
      cropPoints: cropPoints ?? this.cropPoints,
      ocrText: ocrText ?? this.ocrText,
      createdAt: createdAt,
    );
  }
}
