class UserModel {
  final String id;
  final String name;
  final String email;
  final bool isPro;
  final bool cloudEnabled;
  final String languageCode;
  final String createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.isPro,
    required this.cloudEnabled,
    required this.languageCode,
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      isPro: (map['is_pro'] ?? 0) == 1,
      cloudEnabled: (map['cloud_enabled'] ?? 0) == 1,
      languageCode: map['language_code'] ?? 'ar',
      createdAt: map['created_at'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'is_pro': isPro ? 1 : 0,
      'cloud_enabled': cloudEnabled ? 1 : 0,
      'language_code': languageCode,
      'created_at': createdAt,
    };
  }
}
