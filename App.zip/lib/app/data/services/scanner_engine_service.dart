import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class ScannerEngineService {
  static final ScannerEngineService instance = ScannerEngineService._();
  ScannerEngineService._();

  Future<List<Offset>> detectDocumentEdges(String imagePath) async {
    final bytes = await File(imagePath).readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      return const [
        Offset(0.06, 0.06),
        Offset(0.94, 0.06),
        Offset(0.94, 0.94),
        Offset(0.06, 0.94),
      ];
    }

    final small = img.copyResize(decoded, width: 240);
    final gray = img.grayscale(small);

    final w = gray.width;
    final h = gray.height;

    int minX = w, maxX = 0, minY = h, maxY = 0;
    int edgeHits = 0;

    for (int y = 4; y < h - 4; y++) {
      for (int x = 4; x < w - 4; x++) {
        final c = gray.getPixel(x, y).r.toInt();
        final gx = (gray.getPixel(x + 1, y).r.toInt() - gray.getPixel(x - 1, y).r.toInt()).abs();
        final gy = (gray.getPixel(x, y + 1).r.toInt() - gray.getPixel(x, y - 1).r.toInt()).abs();
        final grad = gx + gy;

        if (grad > 65 && c > 90) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
          edgeHits++;
        }
      }
    }

    if (edgeHits < 40 || (maxX - minX) < w * 0.25 || (maxY - minY) < h * 0.25) {
      return const [
        Offset(0.06, 0.06),
        Offset(0.94, 0.06),
        Offset(0.94, 0.94),
        Offset(0.06, 0.94),
      ];
    }

    final left = (minX / w).clamp(0.02, 0.45);
    final right = (maxX / w).clamp(0.55, 0.98);
    final top = (minY / h).clamp(0.02, 0.45);
    final bottom = (maxY / h).clamp(0.55, 0.98);

    return [
      Offset(left, top),
      Offset(right, top),
      Offset(right, bottom),
      Offset(left, bottom),
    ];
  }

  Future<String> processPage({
    required String originalPath,
    required List<Offset> normalizedCorners,
    required String filterType,
    required int rotationDegrees,
  }) async {
    final bytes = await File(originalPath).readAsBytes();
    img.Image? src = img.decodeImage(bytes);
    if (src == null) return originalPath;

    src = _warpPerspective(src, normalizedCorners);

    if (rotationDegrees % 360 != 0) {
      src = img.copyRotate(src, angle: rotationDegrees);
    }

    switch (filterType) {
      case 'magic':
        src = _applyMagicColorFilter(src);
        break;
      case 'bw':
        src = _applyAdaptiveThresholdBW(src);
        break;
      case 'gray':
        src = _applyEnhancedGrayscale(src);
        break;
      case 'lighten':
        src = _applyShadowRemoval(src);
        break;
      case 'original':
      default:
        break;
    }

    final dir = await getApplicationDocumentsDirectory();
    final scansDir = Directory(p.join(dir.path, 'processed_scans'));
    if (!await scansDir.exists()) {
      await scansDir.create(recursive: true);
    }

    final outPath = p.join(scansDir.path, 'scan_${const Uuid().v4()}.jpg');
    final encoded = img.encodeJpg(src, quality: 92);
    await File(outPath).writeAsBytes(encoded);
    return outPath;
  }

  img.Image _warpPerspective(img.Image src, List<Offset> corners) {
    if (corners.length != 4) return src;

    final w = src.width.toDouble();
    final h = src.height.toDouble();

    final tl = Offset(corners[0].dx * w, corners[0].dy * h);
    final tr = Offset(corners[1].dx * w, corners[1].dy * h);
    final br = Offset(corners[2].dx * w, corners[2].dy * h);
    final bl = Offset(corners[3].dx * w, corners[3].dy * h);

    final topWidth = (tr - tl).distance;
    final bottomWidth = (br - bl).distance;
    final targetW = math.max(topWidth, bottomWidth).round().clamp(100, src.width);

    final leftHeight = (bl - tl).distance;
    final rightHeight = (br - tr).distance;
    final targetH = math.max(leftHeight, rightHeight).round().clamp(100, src.height);

    final dst = img.Image(width: targetW, height: targetH);

    final matrix = _computeHomography(
      dstPoints: [
        const Offset(0, 0),
        Offset(targetW - 1.0, 0),
        Offset(targetW - 1.0, targetH - 1.0),
        Offset(0, targetH - 1.0),
      ],
      srcPoints: [tl, tr, br, bl],
    );

    for (int y = 0; y < targetH; y++) {
      for (int x = 0; x < targetW; x++) {
        final denom = matrix[6] * x + matrix[7] * y + matrix[8];
        if (denom.abs() < 1e-7) continue;
        final sx = (matrix[0] * x + matrix[1] * y + matrix[2]) / denom;
        final sy = (matrix[3] * x + matrix[4] * y + matrix[5]) / denom;

        final ix = sx.round().clamp(0, src.width - 1);
        final iy = sy.round().clamp(0, src.height - 1);
        dst.setPixel(x, y, src.getPixel(ix, iy));
      }
    }

    return dst;
  }

  List<double> _computeHomography({
    required List<Offset> dstPoints,
    required List<Offset> srcPoints,
  }) {
    final a = List.generate(8, (_) => List<double>.filled(9, 0.0));
    for (int i = 0; i < 4; i++) {
      final x = dstPoints[i].dx;
      final y = dstPoints[i].dy;
      final u = srcPoints[i].dx;
      final v = srcPoints[i].dy;

      a[2 * i] = [x, y, 1, 0, 0, 0, -u * x, -u * y, u];
      a[2 * i + 1] = [0, 0, 0, x, y, 1, -v * x, -v * y, v];
    }

    for (int i = 0; i < 8; i++) {
      int maxRow = i;
      for (int k = i + 1; k < 8; k++) {
        if (a[k][i].abs() > a[maxRow][i].abs()) maxRow = k;
      }
      final tmp = a[i];
      a[i] = a[maxRow];
      a[maxRow] = tmp;

      final pivot = a[i][i];
      if (pivot.abs() < 1e-9) continue;
      for (int j = i; j < 9; j++) {
        a[i][j] /= pivot;
      }
      for (int k = 0; k < 8; k++) {
        if (k == i) continue;
        final factor = a[k][i];
        for (int j = i; j < 9; j++) {
          a[k][j] -= factor * a[i][j];
        }
      }
    }

    return [
      a[0][8],
      a[1][8],
      a[2][8],
      a[3][8],
      a[4][8],
      a[5][8],
      a[6][8],
      a[7][8],
      1.0,
    ];
  }

  img.Image _applyMagicColorFilter(img.Image src) {
    final normalized = _applyShadowRemoval(src);
    return img.adjustColor(
      normalized,
      contrast: 1.28,
      saturation: 1.22,
      brightness: 1.05,
    );
  }

  img.Image _applyShadowRemoval(img.Image src) {
    final bg = img.copyResize(src, width: math.max(32, src.width ~/ 16));
    final blurredBg = img.gaussianBlur(bg, radius: 4);
    final illumination = img.copyResize(blurredBg, width: src.width, height: src.height);

    final out = img.Image(width: src.width, height: src.height);
    for (int y = 0; y < src.height; y++) {
      for (int x = 0; x < src.width; x++) {
        final p = src.getPixel(x, y);
        final b = illumination.getPixel(x, y);

        final nr = ((p.r / math.max(1, b.r)) * 245).round().clamp(0, 255);
        final ng = ((p.g / math.max(1, b.g)) * 245).round().clamp(0, 255);
        final nb = ((p.b / math.max(1, b.b)) * 245).round().clamp(0, 255);
        out.setPixelRgba(x, y, nr, ng, nb, 255);
      }
    }
    return out;
  }

  img.Image _applyAdaptiveThresholdBW(img.Image src) {
    final clean = _applyShadowRemoval(src);
    final gray = img.grayscale(clean);
    for (int y = 0; y < gray.height; y++) {
      for (int x = 0; x < gray.width; x++) {
        final lum = gray.getPixel(x, y).r;
        final val = lum > 165 ? 255 : 0;
        gray.setPixelRgba(x, y, val, val, val, 255);
      }
    }
    return gray;
  }

  img.Image _applyEnhancedGrayscale(img.Image src) {
    final clean = _applyShadowRemoval(src);
    final gray = img.grayscale(clean);
    return img.adjustColor(gray, contrast: 1.35);
  }
}
