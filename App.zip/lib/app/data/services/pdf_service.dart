import 'dart:io';
import 'dart:ui' as ui;
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:syncfusion_flutter_pdf/pdf.dart' as sf;
import 'package:uuid/uuid.dart';
import '../models/document_page_model.dart';

class PdfService {
  static final PdfService instance = PdfService._();
  PdfService._();

  Future<String> generatePdfFromPages({
    required String title,
    required List<DocumentPageModel> pages,
    int imageQuality = 88,
  }) async {
    final pdf = pw.Document(title: title, author: 'CamScan Pro');

    for (final page in pages) {
      final file = File(page.processedImagePath);
      if (!await file.exists()) continue;

      var bytes = await file.readAsBytes();
      if (imageQuality < 85) {
        final decoded = img.decodeImage(bytes);
        if (decoded != null) {
          bytes = img.encodeJpg(decoded, quality: imageQuality);
        }
      }

      final image = pw.MemoryImage(bytes);
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: pw.EdgeInsets.zero,
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Image(image, fit: pw.BoxFit.contain),
            );
          },
        ),
      );
    }

    final dir = await getApplicationDocumentsDirectory();
    final pdfDir = Directory(p.join(dir.path, 'exported_pdfs'));
    if (!await pdfDir.exists()) {
      await pdfDir.create(recursive: true);
    }

    final safeTitle = title.replaceAll(RegExp(r'[^a-zA-Z0-9_\-\u0600-\u06FF]'), '_');
    final outPath = p.join(pdfDir.path, '${safeTitle}_${const Uuid().v4().substring(0, 6)}.pdf');
    final file = File(outPath);
    await file.writeAsBytes(await pdf.save());
    return outPath;
  }

  Future<String> mergePdfFiles(List<String> pdfPaths) async {
    final sf.PdfDocument outputDocument = sf.PdfDocument();

    for (final path in pdfPaths) {
      final bytes = await File(path).readAsBytes();
      final sf.PdfDocument inputDocument = sf.PdfDocument(inputBytes: bytes);
      for (int i = 0; i < inputDocument.pages.count; i++) {
        final sf.PdfPage page = inputDocument.pages[i];
        final sf.PdfTemplate template = page.createTemplate();
        final sf.PdfPage newPage = outputDocument.pages.add();
        newPage.graphics.drawPdfTemplate(template, const ui.Offset(0, 0));
      }
      inputDocument.dispose();
    }

    final dir = await getApplicationDocumentsDirectory();
    final outPath = p.join(dir.path, 'merged_${const Uuid().v4().substring(0, 6)}.pdf');
    final List<int> savedBytes = await outputDocument.save();
    outputDocument.dispose();

    await File(outPath).writeAsBytes(savedBytes);
    return outPath;
  }

  Future<List<String>> splitPdfFile(String pdfPath) async {
    final bytes = await File(pdfPath).readAsBytes();
    final sf.PdfDocument inputDocument = sf.PdfDocument(inputBytes: bytes);
    final dir = await getApplicationDocumentsDirectory();
    final splitDir = Directory(p.join(dir.path, 'split_${const Uuid().v4().substring(0, 6)}'));
    await splitDir.create(recursive: true);

    final List<String> generatedPaths = [];
    for (int i = 0; i < inputDocument.pages.count; i++) {
      final sf.PdfDocument singleDoc = sf.PdfDocument();
      final sf.PdfTemplate template = inputDocument.pages[i].createTemplate();
      final sf.PdfPage newPage = singleDoc.pages.add();
      newPage.graphics.drawPdfTemplate(template, const ui.Offset(0, 0));

      final pagePath = p.join(splitDir.path, 'page_${i + 1}.pdf');
      await File(pagePath).writeAsBytes(await singleDoc.save());
      singleDoc.dispose();
      generatedPaths.add(pagePath);
    }

    inputDocument.dispose();
    return generatedPaths;
  }

  Future<String> compressPdfFile(String pdfPath) async {
    final bytes = await File(pdfPath).readAsBytes();
    final sf.PdfDocument document = sf.PdfDocument(inputBytes: bytes);
    document.compressionLevel = sf.PdfCompressionLevel.best;

    final dir = await getApplicationDocumentsDirectory();
    final outPath = p.join(dir.path, 'compressed_${const Uuid().v4().substring(0, 6)}.pdf');
    await File(outPath).writeAsBytes(await document.save());
    document.dispose();
    return outPath;
  }
}
