import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class InvoiceParsedData {
  final String vendor;
  final String date;
  final String total;

  InvoiceParsedData({
    required this.vendor,
    required this.date,
    required this.total,
  });
}

class OcrService {
  static final OcrService instance = OcrService._();
  OcrService._();

  Future<String> extractTextFromImage(String imagePath) async {
    final inputImage = InputImage.fromFilePath(imagePath);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final RecognizedText recognizedText = await textRecognizer.processImage(inputImage);
      return recognizedText.text.trim();
    } catch (e) {
      return '';
    } finally {
      await textRecognizer.close();
    }
  }

  InvoiceParsedData parseInvoiceDetails(String rawText) {
    if (rawText.isEmpty) {
      return InvoiceParsedData(vendor: '-', date: '-', total: '-');
    }

    final lines = rawText
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final vendor = lines.isNotEmpty ? lines.first : '-';

    final dateRegex = RegExp(
      r'(\b\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}\b)|(\b\d{4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,2}\b)',
    );
    final dateMatch = dateRegex.firstMatch(rawText);
    final date = dateMatch?.group(0) ?? '-';

    final totalLineRegex = RegExp(
      r'(?:total|sum|gesamt|amount|betrag|الإجمالي|المجموع)[^\d]*(\d+[\.,]\d{2})',
      caseSensitive: false,
    );
    final totalLineMatch = totalLineRegex.firstMatch(rawText);

    String total = '-';
    if (totalLineMatch != null && totalLineMatch.group(1) != null) {
      total = totalLineMatch.group(1)!;
    } else {
      final moneyRegex = RegExp(r'\b\d+[\.,]\d{2}\b');
      final matches = moneyRegex.allMatches(rawText).toList();
      double maxVal = 0.0;
      for (final m in matches) {
        final str = m.group(0)!.replaceAll(',', '.');
        final val = double.tryParse(str) ?? 0.0;
        if (val > maxVal) {
          maxVal = val;
          total = m.group(0)!;
        }
      }
    }

    return InvoiceParsedData(
      vendor: vendor,
      date: date,
      total: total,
    );
  }
}
