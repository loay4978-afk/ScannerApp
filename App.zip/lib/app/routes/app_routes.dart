abstract class AppRoutes {
  static const home = '/home';
  static const scanner = '/scanner';
  static const documentDetail = '/document-detail';
}
