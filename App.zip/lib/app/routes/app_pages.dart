import 'package:get/get.dart';
import '../modules/document_detail/bindings/document_detail_binding.dart';
import '../modules/document_detail/views/document_detail_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';
import '../modules/scanner/bindings/scanner_binding.dart';
import '../modules/scanner/views/scanner_view.dart';
import 'app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(
      name: AppRoutes.home,
      page: () => const HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRoutes.scanner,
      page: () => const ScannerView(),
      binding: ScannerBinding(),
    ),
    GetPage(
      name: AppRoutes.documentDetail,
      page: () => const DocumentDetailView(),
      binding: DocumentDetailBinding(),
    ),
  ];
}
