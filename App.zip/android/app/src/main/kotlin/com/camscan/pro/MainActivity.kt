package com.camscan.pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
