import 'package:flutter_test/flutter_test.dart';
import 'package:camscan_pro/app/data/services/ocr_service.dart';

void main() {
  test('Invoice Parser extracts total and date accurately', () {
    const sampleInvoice = '''
    ACME Cloud GmbH
    Date: 24.11.2026
    Subtotal: 100.00
    Total: 119.00
    ''';

    final parsed = OcrService.instance.parseInvoiceDetails(sampleInvoice);
    expect(parsed.vendor, 'ACME Cloud GmbH');
    expect(parsed.date, '24.11.2026');
    expect(parsed.total, '119.00');
  });
}
